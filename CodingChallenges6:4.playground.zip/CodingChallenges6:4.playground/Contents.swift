import UIKit


let num = 82

// 1st Implementation
if num % 2 == 0 {
    print("\(num) is even")
} else {
    print("\(num) is odd")
}

// 2nd Implementation
func isNumEvenOrOdd (number: Int) -> String {
    if number % 2 == 0 {
        return "\(number) is even"
    } else {
    return "\(number) is odd"
    }
}

isNumEvenOrOdd(number: num)

// 3rd Implementation
func isMyNumEvenOrOdd (number: Int) -> Bool {
    if number % 2 == 0 {
        return true
    } else {
        return false
    }
}

//question: why i am not able to access number here, rather can access num only?
if isMyNumEvenOrOdd(number: num) {
    print("\(num)is even")
} else {
   print("\(num) is odd")
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

let array = [3,54,22,76,33,7,34,2,34,67,73,44]

//Question: equal to condition pending?
var minimumValue = array [0]
for item in array {
    if item < minimumValue {
        minimumValue = item
        print("\(minimumValue) is minimum value here")
    }
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// 1st Implementation
var random1: UInt32
var random2: UInt32

repeat {
    random1 = arc4random_uniform(11)
    random2 = arc4random_uniform(11)
    print("\(random1) and \(random2) via UInt32")
} while random1 != random2

// 2nd Implementation
var r1: Int
var r2: Int

repeat {
    r1 = Int.random(in: 1...15)
    r2 = Int.random(in: 1...15)
    print("\(r1) and \(r2) via Int")
} while r1 != r2

//question: can i use while loope or some other loop instead?






